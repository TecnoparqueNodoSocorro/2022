<div class="container ">
    <div class="container rounded mt-5" id="fondo">
        <hr>
        <div class="text-center">
        <?php
            session_destroy();
            ?>
            <h1>401 error page</h1>
            <a href="index.php?page=login" class="btn btn-warning mb-3"> Volver</a>
        </div>
    </div>
</div>