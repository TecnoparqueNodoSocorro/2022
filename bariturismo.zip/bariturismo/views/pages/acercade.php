<!-- aqui va el inicio menu para los usuarios  -->
<hr>
<hr>
<hr>
<hr>
<hr>
<h1>pagina acerda de</h1>