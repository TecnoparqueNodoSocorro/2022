
<?php
/* if (isset($_SESSION["validar_ingreso"])) {
    if ($_SESSION["rol"] != "1") {
        echo '<script>window.location="index.php?page=error"; </script>';
        return;
    }
} else {
    echo '<script>window.location="index.php?page=login"; </script>';
} */
?>

<div class="container">


    <div class="container1">

        <input type="checkbox" id="btn-mas">

        <div class="redes">
            <a href="#" class="fa fa-youtube">Historia</a>
        </div>
        <div class="redes">
            <a href="#" class="fa fa-facebook">Turismo</a>
        </div>

        <div class="redes">
            <a href="#" class="fa fa-twitter">Restaurantes</a>
        </div>
        <div class="redes">
            <a href="#" class="fa fa-pinterest">Hospedajes</a>
        </div>
        <div class="redes">
            <a href="#" class="fa fa-pinterest">Generales</a>
        </div>
        <div class="btn-mas">
            <label for="btn-mas" class="fa fa-plus"></label>
        </div>
    </div>

    <div class="container2">
        <div class="btn-mas2">
            <label for="btn-mas2" class="fa fa-plus"></label>
        </div>
        <input type="checkbox" id="btn-mas2">

        <div class="redes2">
            <a href="#" class="fa fa-youtube">Historia</a>
        </div>
        <div class="redes2">
            <a href="#" class="fa fa-facebook">Turismo</a>
        </div>

        <div class="redes2">
            <a href="#" class="fa fa-twitter">Restaurantes</a>
        </div>
        <div class="redes2">
            <a href="#" class="fa fa-pinterest">Hospedajes</a>
        </div>
        <div class="redes2">
            <a href="#" class="fa fa-pinterest">Generales</a>
        </div>

    </div>

</div>





<!-- 
<div style="background-color: yellow;">

    <div class="container2">

        <input type="checkbox" id="btn-mas2">

        <div class="redes2">
            <a href="#" class="fa fa-youtube">Historia</a>
        </div>
        <div class="redes2">
            <a href="#" class="fa fa-facebook">Turismo</a>
        </div>

        <div class="redes2">
            <a href="#" class="fa fa-twitter">Restaurantes</a>
        </div>
        <div class="redes2">
            <a href="#" class="fa fa-pinterest">Hospedajes</a>
        </div>
        <div class="redes2">
            <a href="#" class="fa fa-pinterest">Generales</a>
        </div>
        <div class="btn-mas2">
            <label for="btn-mas2" class="fa fa-plus"></label>
        </div>
    </div>
</div> -->