<?php
class ControladorPlantilla
{
    /* llamar  la plantilla */
    public function ctrCargarPlantilla()
    {
        /* include se usa par ainvocar el archivo que contiene el codigo */
        include "views/template.php";
    }
}
